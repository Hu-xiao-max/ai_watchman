import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import St from 'gi://St';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';

export default class UsageExtension extends Extension {
    enable() {
        this._button = new PanelMenu.Button(0.5, 'Claude and Codex Usage');
        this._label = new St.Label({
            text: 'Claude — | Codex —',
            y_align: Clutter.ActorAlign.CENTER,
        });
        this._button.add_child(this._label);
        this._details = new PopupMenu.PopupMenuItem('Loading usage…', {
            reactive: false,
        });
        this._button.menu.addMenuItem(this._details);
        Main.panel.addToStatusArea(this.uuid, this._button);
        this._timer = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 300, () => {
            this._refresh();
            return GLib.SOURCE_CONTINUE;
        });
        this._refresh();
    }

    _refresh() {
        if (this._process)
            return;
        const path = GLib.build_filenamev([this.path, 'ai-usage.py']);
        let process;
        try {
            const launcher = new Gio.SubprocessLauncher({
                flags: Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_SILENCE,
            });
            const localCodex = GLib.build_filenamev([GLib.get_home_dir(), '.local', 'bin', 'codex']);
            if (GLib.file_test(localCodex, GLib.FileTest.IS_EXECUTABLE))
                launcher.setenv('AI_USAGE_CODEX', localCodex, false);
            process = launcher.spawnv(['/usr/bin/nice', '-n', '10', '/usr/bin/python3', path, 'waybar']);
        } catch {
            this._showError();
            return;
        }
        this._process = process;
        process.communicate_utf8_async(null, null, (source, result) => {
            try {
                const [, stdout] = source.communicate_utf8_finish(result);
                if (this._process !== process)
                    return;
                if (!source.get_successful())
                    throw new Error('Usage update failed');
                const {text, tooltip} = JSON.parse(stdout);
                this._label.set_text(text);
                this._details.label.set_text(tooltip);
            } catch {
                if (this._process === process)
                    this._showError();
            } finally {
                if (this._process === process)
                    this._process = null;
            }
        });
    }

    _showError() {
        this._label.set_text('Claude — | Codex —');
        this._details.label.set_text('Usage refresh failed');
    }

    disable() {
        GLib.Source.remove(this._timer);
        this._timer = null;
        this._process = null;
        this._button.destroy();
        this._button = null;
        this._label = null;
        this._details = null;
    }
}
